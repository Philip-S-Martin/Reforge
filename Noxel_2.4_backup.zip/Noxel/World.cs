﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;
/*
namespace Noxel
{
    class World : MonoBehaviour
    {
        List<StructureData> structures;
        List<GameObject> structureObjects;
        StructureRenderer structureRenderer;
        Structure structureManipulator;

        public World()
        {
            structures = new List<StructureData>();
            structureRenderer = new StructureRenderer();
            structureManipulator = new Structure();
        }
    }
}
*/