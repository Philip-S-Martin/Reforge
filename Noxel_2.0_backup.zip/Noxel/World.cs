﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;
/*
namespace Assets.Noxel
{
    class World : MonoBehaviour
    {
        List<StructureData> structures;
        List<GameObject> structureObjects;
        StructureRenderer structureRenderer;
        Structure structureManipulator;

        public World()
        {
            structures = new List<StructureData>();
            structureRenderer = new StructureRenderer();
            structureManipulator = new Structure();
        }
    }
}
*/